kill -9 4536
./frpc -c ./frpc.ini  
